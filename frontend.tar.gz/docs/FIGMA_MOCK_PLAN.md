# Figma Mock Plan (Ready to Build)

Use this in your Figma file:
https://www.figma.com/design/BIoGc1xoYmQqdXYuYBdJm6/Untitled?node-id=0-1&p=f&t=PHL9cVp4zmNvHrl2-0

## 1) Create Pages
- `00 Foundations`
- `01 Auth`
- `02 Dashboard`
- `03 Accounts`
- `04 Transactions`
- `05 Customers (Admin)`
- `06 Components`

## 2) Foundations Setup
Add color styles:
- `bg/base`: `#F7F5F0`
- `surface/card`: `#FFFDF8`
- `ink/primary`: `#11212D`
- `brand/teal`: `#0F766E`
- `accent/orange`: `#C2410C`
- `state/success`: `#166534`
- `state/danger`: `#991B1B`

Add typography styles:
- `H1`: Space Grotesk 44/52 SemiBold
- `H2`: Space Grotesk 32/40 SemiBold
- `H3`: Space Grotesk 24/32 Medium
- `Body`: Source Sans 3 16/24 Regular
- `Label`: Source Sans 3 14/20 Semibold
- `Mono`: IBM Plex Mono 13/18

Add spacing scale:
- 4, 8, 12, 16, 24, 32, 48, 64

## 3) Frame List
Desktop (1440x1024):
- Login
- Dashboard
- Accounts List
- Account Detail
- Transaction History
- Customers List (Admin)
- Customer Detail (Admin)
- Transfer Form

Mobile (390x844):
- Login
- Dashboard
- Account Detail
- Transfer Form

## 4) Component Inventory
Build as variants in `06 Components`:
- Button: primary / secondary / danger / ghost
- Input: default / error / disabled
- Select: default / open / error
- Card: KPI / account / transaction summary
- Badge: admin / customer / checking / savings / transaction type
- Table row: default / hover / selected
- Alert: error / warning / success
- Modal: create-customer / create-account / confirm-delete

## 5) Screen Content Specs
Login:
- Left panel: brand message and trust microcopy.
- Right panel: username + password + sign in CTA.
- Include 401 and 403 inline error variants.

Dashboard:
- Top: 4 KPI cards.
- Mid: recent transactions table.
- Right rail: quick actions (deposit, withdraw, transfer, create account).

Accounts List:
- Toolbar: search, account type filter, role indicator.
- Table columns: accountNumber, customerId, type, balance, interestRate, actions.

Account Detail:
- Hero card with balance and interest rate.
- Two side-by-side forms: deposit and withdrawal.
- Transaction snippet list (latest 5).

Transfer Form:
- sourceAccountNumber, destinationAccountNumber, amount.
- Confirmation state and success toast.

Customers (Admin):
- Customer table: id, username, actions.
- Create customer modal.
- Customer detail with nested account list and create account action.

## 6) Prototype Flows
Connect these click paths in prototype mode:
- Login -> Dashboard
- Dashboard -> Account Detail
- Account Detail -> Transactions
- Dashboard -> Transfer Form
- Customers List -> Customer Detail
- Customer Detail -> Create Account modal -> Success

## 7) Handoff Notes
Annotate these rules directly on frames:
- All amount fields must support up to 2 decimals.
- Transfer and withdrawal must show insufficient funds errors.
- Forbidden resource access maps to a full-width 403 alert state.
- 409 conflict shows retry CTA.
