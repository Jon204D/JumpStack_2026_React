# Console Bank Frontend Plan (React + TypeScript)

## 1) Product Goal
Build a secure banking dashboard UI for two roles:
- `ADMIN`: create customers, create accounts, view all customers/accounts, delete resources.
- `CUSTOMER`: view only own profile/accounts, view transactions, deposit, withdraw, transfer.

Backend alignment is based on `JumpStack_2026` endpoints under:
- `/api/customers`
- `/api/accounts`
- HTTP Basic auth with stateless sessions.

## 2) Recommended Tech Stack
- React 18+
- TypeScript
- Vite
- React Router
- TanStack Query
- Zod (client validation + API parsing)
- React Hook Form
- Axios
- Zustand (optional for small shared UI state)
- Vitest + React Testing Library

## 3) App Information Architecture
Routes:
- `/login`
- `/app/dashboard`
- `/app/customers` (admin)
- `/app/customers/:customerId` (admin or self)
- `/app/accounts` (admin list)
- `/app/accounts/:accountNumber`
- `/app/accounts/:accountNumber/transactions`
- `/app/transfers/new`
- `/app/settings`

Primary layout:
- Left nav: Dashboard, Accounts, Transactions, Customers (admin), Transfer, Settings.
- Top bar: role badge, authenticated username, environment badge (DEV/QA/PROD), sign out.
- Main content: card-first, data grid for lists, drawer-based create/edit forms.

## 4) Visual Direction (for intentional, non-generic UI)
Theme name: **Ledger Atlas**

Design language:
- Typography: `Space Grotesk` for headings, `Source Sans 3` for body.
- Palette:
  - `--bg`: `#F7F5F0`
  - `--surface`: `#FFFDF8`
  - `--ink`: `#11212D`
  - `--brand`: `#0F766E` (deep teal)
  - `--accent`: `#C2410C` (burnt orange)
  - `--success`: `#166534`
  - `--danger`: `#991B1B`
- Shape: 14px radius cards, 1px high-contrast borders.
- Atmosphere: subtle paper grain background + warm top gradient.
- Motion:
  - page enter: 180ms rise/fade
  - list row stagger: 30ms per row
  - KPI counters: ease-out number tween

## 5) Screen-by-Screen MVP
1. Login
- Username + password
- Role-aware landing route after auth
- Error banner for `401/403`

2. Dashboard
- KPI cards: total accounts, total customers (admin only), balances, transfer volume
- Recent transactions table
- Quick actions: Deposit, Withdraw, Transfer, Create Account

3. Accounts List
- Admin: all accounts
- Customer: own accounts shortcut
- Search by account number
- Chips for account type (`CHECKING`, `SAVINGS`)

4. Account Detail
- Account summary card
- Action panel: deposit, withdrawal
- Transfer CTA
- Link to transaction history

5. Transactions
- Timeline/table with:
  - `type` (`DEPOSIT`, `WITHDRAWAL`, `TRANSFER`)
  - source/destination
  - amount
  - createdAt
- Filters: type, min amount, date range

6. Customers (Admin)
- Customers table
- Create customer modal
- Customer detail includes account list and create-account action

## 6) Backend Contract Mapping
Authentication:
- HTTP Basic on all `/api/**` except health/error.
- Keep credentials in memory only during session.

Error model (`ApiError`):
- `timestamp`, `status`, `error`, `message`, `path`, `fieldErrors`

Handle specifically:
- `400`: validation + business errors (insufficient funds)
- `403`: unauthorized resource access
- `404`: missing account/customer
- `409`: duplicate resource / optimistic lock conflict

## 7) Frontend Folder Blueprint
Suggested structure:

```txt
src/
  app/
    router.tsx
    providers.tsx
  features/
    auth/
      api.ts
      hooks.ts
      store.ts
      LoginPage.tsx
    dashboard/
      DashboardPage.tsx
      kpis.ts
    customers/
      api.ts
      CustomersPage.tsx
      CustomerDetailPage.tsx
      components/
    accounts/
      api.ts
      AccountsPage.tsx
      AccountDetailPage.tsx
      TransactionsPage.tsx
      components/
    transfers/
      TransferPage.tsx
  shared/
    api/client.ts
    api/types.ts
    components/
    utils/
    theme/
      tokens.css
```

## 8) MVP Delivery Sequence
1. Auth + API client foundation.
2. Dashboard + accounts read flows.
3. Deposit/withdraw/transfer actions.
4. Customer/admin flows.
5. Validation polish + optimistic error states.
6. Unit tests + integration smoke tests.

## 9) Non-Functional Requirements
- Accessible forms and table keyboard navigation.
- Currency formatting via `Intl.NumberFormat`.
- Empty/loading/error states on every data view.
- Retry pattern for `409` and transient errors.
- Strict DTO type parity with backend.
