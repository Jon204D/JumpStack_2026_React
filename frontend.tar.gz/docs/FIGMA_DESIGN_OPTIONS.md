# Figma Design Options for Console Bank App

This gives you three visual directions for the same backend-aligned product scope.
Pick one direction, then build the listed frames in your existing Figma file.

## Option A: Ledger Atlas (Editorial + Trust)
Best for: modern bank feel with personality and high readability.

Visual DNA:
- Warm paper background with subtle texture.
- Deep teal brand color with burnt orange accents.
- Large editorial headings and compact body text.

Style tokens:
- Background: `#F7F5F0`
- Surface: `#FFFDF8`
- Primary ink: `#11212D`
- Brand: `#0F766E`
- Accent: `#C2410C`
- Success: `#166534`
- Danger: `#991B1B`
- Radius: 14
- Border: 1px, `#D9D5CC`

Core frames to design:
- Login (split hero + form)
- Dashboard (KPI cards, quick actions, recent transactions)
- Accounts List (table + filters)
- Account Detail (balance hero + deposit/withdraw cards)
- Transfer Flow (form + confirm + success)
- Customers Admin (list + create modal)

Motion ideas:
- KPI cards fade-up stagger (80ms intervals)
- Table rows reveal stagger (30ms)
- Success states use scale 0.98 -> 1

## Option B: Ops Terminal (Data-Dense + Professional)
Best for: admin-heavy workflows and faster scanning.

Visual DNA:
- Neutral cool palette and strict grid.
- Information-first components, less decoration.
- Strong hierarchy for financial values.

Style tokens:
- Background: `#EEF2F5`
- Surface: `#FFFFFF`
- Primary ink: `#1F2937`
- Brand: `#0B5FFF`
- Accent: `#D97706`
- Success: `#0F766E`
- Danger: `#B91C1C`
- Radius: 10
- Border: 1px, `#D1D5DB`

Core frames to design:
- Login (single centered card)
- Admin Dashboard (global metrics)
- Customer Drilldown (customer profile + account table)
- Global Accounts Grid (sortable columns)
- Account Transactions Explorer (filters and pagination)
- Error States (403, 404, 409, validation)

Motion ideas:
- Low-motion transitions only
- Sticky table header with subtle shadow shift on scroll

## Option C: Neo Retail (Mobile-First + Card-Centric)
Best for: customer-facing experience first, admin second.

Visual DNA:
- High-contrast cards and bold numeric typography.
- Strong CTA buttons for transfer/deposit/withdraw.
- Mobile-first layouts adapted to desktop.

Style tokens:
- Background: `#F4F8FF`
- Surface: `#FFFFFF`
- Primary ink: `#0F172A`
- Brand: `#0284C7`
- Accent: `#7C3AED`
- Success: `#15803D`
- Danger: `#DC2626`
- Radius: 18
- Border: 1px, `#DBE3F0`

Core frames to design:
- Mobile Login
- Mobile Dashboard
- Account Detail with transaction mini-feed
- Transfer form wizard (3-step)
- Desktop admin overlay for customer management

Motion ideas:
- Slide transitions between transfer steps
- Progress indicator animation for transaction submission

## Shared Functional Components (All Options)
Build these as reusable variants:
- Buttons: primary, secondary, danger, ghost, loading
- Inputs: default, focus, error, disabled
- Amount field with currency prefix and decimal hint
- Account type badge: CHECKING, SAVINGS
- Transaction badge: DEPOSIT, WITHDRAWAL, TRANSFER
- Alert bars: 400 validation, 403 forbidden, 404 not found, 409 retry
- Modals: create customer, create account, confirm deletion

## Backend-Aligned Content Rules
- Amount precision: max 2 decimals.
- Transfer request fields:
  - sourceAccountNumber
  - destinationAccountNumber
  - amount
- Create account fields:
  - accountNumber
  - type (CHECKING/SAVINGS)
  - startingBalance
- Create customer fields:
  - username
  - password

## Suggested Figma Page Structure
- `00 Foundations`
- `01 Option A - Ledger Atlas`
- `02 Option B - Ops Terminal`
- `03 Option C - Neo Retail`
- `04 Components`
- `05 Prototype Flows`

## Prototype Flows to Connect
- Login -> Dashboard
- Dashboard -> Account Detail
- Account Detail -> Deposit/Withdraw success states
- Dashboard -> Transfer flow -> success
- Admin Customers -> Create Customer -> Customer Detail -> Create Account
- Any protected route error -> 403 state and recover action

## Recommendation
Start with Option A for your first pass because it balances brand feel with enterprise clarity, then borrow the denser table treatment from Option B for admin screens.
