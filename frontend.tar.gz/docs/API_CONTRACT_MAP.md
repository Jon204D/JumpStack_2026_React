# API Contract Map (from JumpStack_2026 backend)

## Auth
- Scheme: HTTP Basic
- Stateless backend security
- Roles: `ROLE_ADMIN`, `ROLE_CUSTOMER`

`GET /api/auth/me` (authenticated users)
Response `200`:
```json
{
  "username": "customer1",
  "role": "CUSTOMER",
  "customerId": "customer-id-or-null-for-admin"
}
```

## Customers
`POST /api/customers` (admin)
Request:
```json
{
  "username": "string (required, max 50)",
  "password": "string (required, 8-72)"
}
```
Response `201`:
```json
{ "id": "string", "username": "string" }
```

`GET /api/customers` (admin)
Response `200`:
```json
[{ "id": "string", "username": "string" }]
```

`GET /api/customers/{customerId}` (admin or self)
`GET /api/customers/{customerId}/accounts` (admin or self)

`POST /api/customers/{customerId}/accounts` (admin)
Request:
```json
{
  "accountNumber": "string (letters/numbers/hyphens)",
  "type": "CHECKING | SAVINGS",
  "startingBalance": 0
}
```
Response `201`:
```json
{
  "id": "string",
  "accountNumber": "string",
  "customerId": "string",
  "type": "CHECKING",
  "balance": 0,
  "interestRate": 0
}
```

`DELETE /api/customers/{customerId}` (admin)

## Accounts
`GET /api/accounts` (admin)
`GET /api/accounts/{accountNumber}` (admin or owner)

`POST /api/accounts/{accountNumber}/deposits`
`POST /api/accounts/{accountNumber}/withdrawals`
Request:
```json
{ "amount": 0.01 }
```
Response `200`: `AccountResponse`

`POST /api/accounts/transfers`
Request:
```json
{
  "sourceAccountNumber": "string",
  "destinationAccountNumber": "string",
  "amount": 0.01
}
```
Response `204`

`GET /api/accounts/{accountNumber}/transactions`
Response `200`:
```json
[
  {
    "id": "string",
    "type": "DEPOSIT | WITHDRAWAL | TRANSFER",
    "sourceAccountNumber": "string | null",
    "destinationAccountNumber": "string | null",
    "amount": 0,
    "createdAt": "2026-07-15T00:00:00Z"
  }
]
```

`DELETE /api/accounts/{accountNumber}` (admin)

## Error Envelope
```json
{
  "timestamp": "2026-07-15T00:00:00Z",
  "status": 400,
  "error": "Bad Request",
  "message": "Request validation failed",
  "path": "/api/accounts/transfers",
  "fieldErrors": {
    "amount": "Amount must be at least 0.01"
  }
}
```
